package PlaceTravel.demo.dto;


import lombok.Data;

@Data
public class PlaceDto {

    private Long id;
    private String name;

}
